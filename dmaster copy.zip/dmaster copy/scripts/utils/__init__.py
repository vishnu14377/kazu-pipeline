"""
This module contains utility functions for ontology operations.
"""
